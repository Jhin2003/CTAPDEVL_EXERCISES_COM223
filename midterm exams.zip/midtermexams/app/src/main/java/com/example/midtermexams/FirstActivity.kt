package com.example.midtermexams

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FirstActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        // Set up window insets (for edge-to-edge UI)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show a toast for the created state
        Log.d("Activity", "Activity One has been CREATED")


        val editTextField = findViewById<EditText>(R.id.editTextText)
        val loginButton = findViewById<Button>(R.id.button2)

        loginButton.setOnClickListener {
            val inputField = editTextField.text.toString()
            val intent = Intent(this, SecondActivity::class.java)

            intent.putExtra("firstInput", inputField)
            startActivity(intent)


        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("Activity", "Activity One has STARTED")
    }

    override fun onResume() {
        super.onResume()
        Log.d("Activity", "Activity One has RESUMED")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Activity", "Activity One has PAUSED")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Activity", "Activity One has STOPPED")
    }

    override fun onRestart() {
        super.onRestart()
        Log.d("Activity", "Activity One has RESTARTED")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Activity", "Activity One has DESTROYED")
    }

    // Method to show a Toast with the current lifecycle state

}